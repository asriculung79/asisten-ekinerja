import { describe, it, expect } from "vitest";
import {
  normTanggal,
  normJam,
  rowToProgres,
  validasi,
  TARGET_MENIT_HARIAN,
  type Progres,
} from "@/lib/progres";

const p = (o: Partial<Progres>): Progres => ({
  id: "a",
  rencanaAksiId: "r",
  tanggal: "2025-10-20",
  jamMulai: "08:00",
  jamSelesai: "09:00",
  kegiatan: "x",
  realisasi: "",
  linkBukti: "",
  selesai: false,
  status: "draft",
  ...o,
});
const ra = { id: "r", nama: "RA", jenis: "Trajectory" as const, target: 1, satuan: "konsultasi" };

describe("progres", () => {
  it("dd/mm/yyyy jadi ISO", () => expect(normTanggal("07/10/2026")).toBe("2026-10-07"));
  it("jam 8.30 jadi 08:30", () => expect(normJam("8.30")).toBe("08:30"));
  it("baris excel cocokkan rencana aksi", () =>
    expect(
      rowToProgres(
        {
          "Tanggal Kegiatan": "01/10/2026",
          "Rencana Aksi": "ra",
          "Rencana Kegiatan Harian": "Rapat",
        },
        [ra],
      ).rencanaAksiId,
    ).toBe("r"));
  it("target harian 7 jam 30 menit", () => expect(TARGET_MENIT_HARIAN).toBe(450));
  it("jam bertabrakan ditolak", () =>
    expect(validasi(p({}), [p({ id: "b", jamMulai: "08:30", jamSelesai: "10:00" })], ra)).toContain(
      "Jam bertabrakan dengan kegiatan lain",
    ));
});
