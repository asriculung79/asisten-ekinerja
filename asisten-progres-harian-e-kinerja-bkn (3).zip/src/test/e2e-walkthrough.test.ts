import { describe, it, expect } from "vitest";
import {
  newId,
  normTanggal,
  normJam,
  toMenit,
  durasi,
  fmtMenit,
  validasi,
  rowToProgres,
  toPayload,
  bookmarkletHref,
  TARGET_MENIT_HARIAN,
  type RencanaAksi,
  type Progres,
} from "@/lib/progres";
import * as XLSX from "xlsx";

describe("End-to-End Walkthrough: Alur Asisten Progres Harian e-Kinerja BKN", () => {
  // 1. Modul Rencana Aksi
  const raTrajectory: RencanaAksi = {
    id: "ra-1",
    nama: "Menyusun Analisis Kebutuhan Pelatihan ASN",
    jenis: "Trajectory",
    target: 4,
    satuan: "Dokumen",
  };

  const raNonTrajectory: RencanaAksi = {
    id: "ra-2",
    nama: "Melaksanakan Konsultasi Layanan Kepegawaian",
    jenis: "Non - Trajectory",
    target: 1,
    satuan: "Kegiatan",
  };

  const daftarRA = [raTrajectory, raNonTrajectory];

  it("Langkah 1: Pembuatan dan validasi skema Rencana Aksi", () => {
    expect(raTrajectory.jenis).toBe("Trajectory");
    expect(raTrajectory.target).toBe(4);
    expect(raTrajectory.satuan).toBe("Dokumen");

    expect(raNonTrajectory.jenis).toBe("Non - Trajectory");
    expect(raNonTrajectory.satuan).toBe("Kegiatan");
  });

  // 2. Modul Input Kegiatan Harian & Validasi Waktu
  const tanggalHariIni = "2026-10-28";

  const kegiatanPagi: Progres = {
    id: newId(),
    rencanaAksiId: raTrajectory.id,
    tanggal: tanggalHariIni,
    jamMulai: "08:00",
    jamSelesai: "11:30", // 3.5 jam = 210 menit
    kegiatan: "Rapat koordinasi dan pengumpulan data kebutuhan diklat teknis",
    realisasi: "1",
    linkBukti: "https://drive.google.com/file/d/sample-1/view",
    selesai: false,
    status: "draft",
  };

  const kegiatanSiang: Progres = {
    id: newId(),
    rencanaAksiId: raNonTrajectory.id,
    tanggal: tanggalHariIni,
    jamMulai: "12:30",
    jamSelesai: "16:30", // 4.0 jam = 240 menit
    kegiatan: "Pelayanan konsultasi dan verifikasi berkas mutasi ASN",
    realisasi: "15",
    linkBukti: "https://drive.google.com/file/d/sample-2/view",
    selesai: true,
    status: "draft",
  };

  it("Langkah 2: Validasi waktu dan deteksi target jam kerja (450 menit / 7.5 jam)", () => {
    // Validasi kegiatan pagi
    const errsPagi = validasi(kegiatanPagi, [], raTrajectory);
    expect(errsPagi).toHaveLength(0);

    // Validasi kegiatan siang terhadap kegiatan pagi (tidak ada benturan waktu)
    const errsSiang = validasi(kegiatanSiang, [kegiatanPagi], raNonTrajectory);
    expect(errsSiang).toHaveLength(0);

    const durasiPagi = durasi(kegiatanPagi);
    const durasiSiang = durasi(kegiatanSiang);
    const totalMenit = durasiPagi + durasiSiang; // 210 + 240 = 450 menit

    expect(durasiPagi).toBe(210);
    expect(durasiSiang).toBe(240);
    expect(totalMenit).toBe(TARGET_MENIT_HARIAN);
    expect(fmtMenit(totalMenit)).toBe("7 Jam 30 Menit");
  });

  it("Langkah 3: Pencegahan benturan waktu (overlap) kegiatan", () => {
    const kegiatanBentrok: Progres = {
      id: newId(),
      rencanaAksiId: raTrajectory.id,
      tanggal: tanggalHariIni,
      jamMulai: "10:00", // Menabrak jadwal kegiatan pagi (08:00 - 11:30)
      jamSelesai: "12:00",
      kegiatan: "Kegiatan tumpang tindih",
      realisasi: "",
      linkBukti: "",
      selesai: false,
      status: "draft",
    };

    const errs = validasi(kegiatanBentrok, [kegiatanPagi, kegiatanSiang], raTrajectory);
    expect(errs).toContain("Jam bertabrakan dengan kegiatan lain");
  });

  it("Langkah 4: Validasi format tanggal, jam selesai, dan link HTTPS", () => {
    const dataRusak: Progres = {
      id: newId(),
      rencanaAksiId: raTrajectory.id,
      tanggal: "28/10/2026", // format bukan YYYY-MM-DD
      jamMulai: "15:00",
      jamSelesai: "14:00", // jam selesai mendahului jam mulai
      kegiatan: "", // kegiatan kosong
      realisasi: "",
      linkBukti: "ftp://contoh.com/file", // bukan https
      selesai: false,
      status: "draft",
    };

    const errs = validasi(dataRusak, [], raTrajectory);
    expect(errs).toContain("Tanggal tidak valid");
    expect(errs).toContain("Rencana kegiatan harian kosong");
    expect(errs).toContain("Jam selesai harus setelah jam mulai");
    expect(errs).toContain("Link bukti dukung harus diawali https://");
  });

  // 3. Modul Ekspor & Impor Excel
  it("Langkah 5: Siklus Impor dan Pencocokan Excel", () => {
    // Simulasi data dari sheet Excel
    const rowExcel = {
      "Tanggal Kegiatan": "28/10/2026",
      "Jam Mulai": "08.00",
      "Jam Selesai": "11.30",
      "Rencana Aksi": "menyusun analisis kebutuhan pelatihan asn",
      "Rencana Kegiatan Harian": "Rapat koordinasi diklat",
      Realisasi: "1",
      "Bukti Dukung": "https://drive.google.com/sample",
    };

    const progresDariExcel = rowToProgres(rowExcel, daftarRA);

    expect(progresDariExcel.tanggal).toBe("2026-10-28");
    expect(progresDariExcel.jamMulai).toBe("08:00");
    expect(progresDariExcel.jamSelesai).toBe("11:30");
    expect(progresDariExcel.rencanaAksiId).toBe(raTrajectory.id);
    expect(progresDariExcel.kegiatan).toBe("Rapat koordinasi diklat");
    expect(progresDariExcel.status).toBe("draft");
  });

  // 4. Modul Bookmarklet & Transisi Status yang Jujur
  it("Langkah 6: Pembentukan payload bookmarklet dan transisi status akurat", () => {
    const listKegiatan = [kegiatanPagi, kegiatanSiang];

    // Payload yang akan disalin ke clipboard
    const rawPayload = toPayload(listKegiatan, daftarRA);
    const parsedPayload = JSON.parse(rawPayload);

    expect(parsedPayload.__progresHarian).toBe(2);
    expect(parsedPayload.items).toHaveLength(2);
    expect(parsedPayload.items[0].rencanaAksi).toBe(raTrajectory.nama);
    expect(parsedPayload.items[0].tanggal).toBe(tanggalHariIni);
    expect(parsedPayload.items[0].jamMulai).toBe("08:00");
    expect(parsedPayload.items[0].jamSelesai).toBe("11:30");
    expect(parsedPayload.items[1].rencanaAksi).toBe(raNonTrajectory.nama);
    expect(parsedPayload.items[1].selesai).toBe(true);

    // Verifikasi bookmarklet href executable
    const href = bookmarkletHref();
    expect(href.startsWith("javascript:")).toBe(true);
    expect(href).toContain("ekinerjaFiller");

    // Transisi status: draft -> disalin (Siap Diisi) -> terverifikasi (Tersimpan di BKN)
    let statusSimulasi = kegiatanPagi.status;
    expect(statusSimulasi).toBe("draft");

    // Simulasi klik "Salin untuk e-Kinerja"
    statusSimulasi = "disalin";
    expect(statusSimulasi).toBe("disalin");

    // Simulasi verifikasi selesai di portal BKN
    statusSimulasi = "terverifikasi";
    expect(statusSimulasi).toBe("terverifikasi");
  });
});
