import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  bookmarkletHref,
  copyText,
  durasi,
  exportExcel,
  fmtMenit,
  importExcel,
  load,
  newId,
  save,
  TARGET_MENIT_HARIAN,
  toPayload,
  validasi,
  type JenisTarget,
  type Progres,
  type RencanaAksi,
} from "@/lib/progres";
import {
  FileUp,
  FileDown,
  Send,
  Trash2,
  Plus,
  Bookmark,
  ExternalLink,
  LogIn,
  LogOut,
  Check,
  CheckCircle2,
  Clock,
  ListTodo,
} from "lucide-react";
import { BuktiUpload } from "@/components/BuktiUpload";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import type { Session } from "@supabase/supabase-js";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Asisten Progres Harian e-Kinerja BKN" },
      {
        name: "description",
        content:
          "Susun rencana aksi dan progres harian, cek keakuratannya, lalu isi otomatis ke e-Kinerja BKN.",
      },
      { property: "og:title", content: "Asisten Progres Harian e-Kinerja BKN" },
      {
        property: "og:description",
        content:
          "Impor Excel, validasi jam kerja, dan isi otomatis formulir Progress Harian e-Kinerja.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

const today = () => new Date().toISOString().slice(0, 10);
const emptyP = (raId = "", tanggal = today(), mulai = "08:00"): Progres => ({
  id: newId(),
  rencanaAksiId: raId,
  tanggal,
  jamMulai: mulai,
  jamSelesai: mulai,
  kegiatan: "",
  realisasi: "",
  linkBukti: "",
  selesai: false,
  status: "draft",
});

function Index() {
  const [mounted, setMounted] = useState(false);
  const [session, setSession] = useState<Session | null | undefined>(undefined);
  const [localMode, setLocalMode] = useState<boolean>(false);

  useEffect(() => {
    setMounted(true);
    if (typeof window !== "undefined") {
      setLocalMode(localStorage.getItem("ekinerja_local_mode") === "true");
    }
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => data.subscription.unsubscribe();
  }, []);

  if (!mounted || (session === undefined && !localMode))
    return <div className="p-10 text-center text-muted-foreground">Memuat…</div>;

  if (session) {
    return <App key={session.user.id} userId={session.user.id} email={session.user.email ?? ""} />;
  }

  if (localMode) {
    return (
      <App
        key="local-mode"
        userId="local-user"
        email="Mode Data Lokal (Browser)"
        onExitLocal={() => {
          localStorage.removeItem("ekinerja_local_mode");
          setLocalMode(false);
        }}
      />
    );
  }

  return (
    <Login
      onUseLocal={() => {
        localStorage.setItem("ekinerja_local_mode", "true");
        setLocalMode(true);
      }}
    />
  );
}

function Login({ onUseLocal }: { onUseLocal?: () => void }) {
  const masuk = async () => {
    const r = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (r.error) toast.error("Gagal masuk: " + (r.error.message ?? r.error));
  };
  return (
    <div className="flex min-h-screen items-center justify-center bg-header p-6 text-primary-foreground">
      <div className="max-w-md text-center">
        <p className="text-sm uppercase tracking-widest text-accent">e-Kinerja BKN</p>
        <h1 className="mt-2 font-display text-4xl">Asisten Progres Harian</h1>
        <p className="mt-3 opacity-80">
          Masuk dengan akun Google Anda untuk menyimpan data ke akun Supabase, atau gunakan mode
          data lokal untuk menyimpan langsung di browser perangkat Anda.
        </p>
        <div className="mt-6 flex flex-col gap-3">
          <Button size="lg" variant="secondary" className="w-full" onClick={masuk}>
            <LogIn /> Masuk dengan Google
          </Button>
          {onUseLocal && (
            <Button
              size="lg"
              variant="outline"
              className="w-full border-white/30 bg-white/10 text-white hover:bg-white/20"
              onClick={onUseLocal}
            >
              Lanjutkan dengan Data Lokal (Browser)
            </Button>
          )}
        </div>
        <p className="mt-4 text-xs opacity-60">
          Data mode lokal tersimpan aman di browser Anda dan otomatis disinkronkan ke akun Supabase
          saat Anda berhasil login.
        </p>
      </div>
    </div>
  );
}

function App({
  userId,
  email,
  onExitLocal,
}: {
  userId: string;
  email: string;
  onExitLocal?: () => void;
}) {
  const [ras, setRas] = useState<RencanaAksi[]>([]);
  const [list, setList] = useState<Progres[]>([]);
  const [ready, setReady] = useState(false);
  const [form, setForm] = useState<Progres>(() => emptyP());
  const [raForm, setRaForm] = useState({
    nama: "",
    jenis: "Trajectory" as JenisTarget,
    target: 1,
    satuan: "",
  });
  const [hari, setHari] = useState(today());
  const fileRef = useRef<HTMLInputElement>(null);
  const bmRef = useRef<HTMLAnchorElement>(null);

  useEffect(() => {
    (async () => {
      if (userId === "local-user") {
        const lr = load<RencanaAksi>("ra-v2");
        const lp = load<Progres>("progres-v2");
        setRas(lr);
        setList(lp);
        setReady(true);
        return;
      }
      const { data, error } = await supabase
        .from("user_data")
        .select("rencana_aksi, progres")
        .eq("user_id", userId)
        .maybeSingle();
      if (error) {
        toast.error("Gagal memuat data akun");
        return;
      }
      let r = (data?.rencana_aksi as unknown as RencanaAksi[]) ?? [];
      let p = (data?.progres as unknown as Progres[]) ?? [];
      if (!data || (!r.length && !p.length)) {
        const lr = load<RencanaAksi>("ra-v2"),
          lp = load<Progres>("progres-v2");
        if (lr.length || lp.length) {
          r = lr;
          p = lp;
          toast.success("Data dari browser ini dipindahkan ke akun Anda");
        }
      }
      setRas(r);
      setList(p);
      setReady(true);
    })();
  }, [userId]);
  useEffect(() => {
    if (!ready) return;
    if (userId === "local-user") {
      save("ra-v2", ras);
      save("progres-v2", list);
      return;
    }
    const t = setTimeout(async () => {
      const { error } = await supabase.from("user_data").upsert({
        user_id: userId,
        rencana_aksi: ras as never,
        progres: list as never,
        updated_at: new Date().toISOString(),
      });
      if (error) toast.error("Gagal menyimpan ke akun");
    }, 600);
    return () => clearTimeout(t);
  }, [ras, list, ready, userId]);
  useEffect(() => {
    bmRef.current?.setAttribute("href", bookmarkletHref());
  }, []);

  const raById = (id: string) => ras.find((r) => r.id === id);
  const harian = useMemo(
    () =>
      list.filter((p) => p.tanggal === hari).sort((a, b) => a.jamMulai.localeCompare(b.jamMulai)),
    [list, hari],
  );
  const total = harian.reduce((s, p) => s + durasi(p), 0);

  const addRa = () => {
    if (!raForm.nama.trim()) {
      toast.error("Nama rencana aksi wajib diisi");
      return;
    }
    const satuan = raForm.jenis === "Non - Trajectory" ? "Kegiatan" : raForm.satuan || "Kegiatan";
    const ra = { ...raForm, satuan, id: newId() };
    setRas((r) => [...r, ra]);
    setForm((f) => ({ ...f, rencanaAksiId: f.rencanaAksiId || ra.id }));
    setRaForm({ nama: "", jenis: "Trajectory", target: 1, satuan: "" });
  };

  const add = () => {
    const errs = validasi(form, list, raById(form.rencanaAksiId));
    if (errs.length) {
      toast.error(errs.join(" · "));
      return;
    }
    setList((l) => [...l, { ...form, id: newId() }]);
    setHari(form.tanggal);
    setForm(emptyP(form.rencanaAksiId, form.tanggal, form.jamSelesai));
    toast.success("Progres ditambahkan");
  };

  const onImport = async (f?: File) => {
    if (!f) return;
    try {
      const rows = await importExcel(f, ras);
      if (!rows.length) {
        toast.error("Tidak ada baris valid. Gunakan template.");
        return;
      }
      setList((l) => [...l, ...rows]);
      toast.success(`${rows.length} progres diimpor. Periksa yang bertanda merah.`);
    } catch {
      toast.error("File tidak bisa dibaca");
    }
    if (fileRef.current) fileRef.current.value = "";
  };

  const [mobileTab, setMobileTab] = useState<"input" | "progres">("progres");

  const kirim = async () => {
    const ok = harian.filter((p) => validasi(p, list, raById(p.rencanaAksiId)).length === 0);
    if (!ok.length) {
      toast.error("Belum ada progres valid di hari ini");
      return;
    }
    const copied = await copyText(toPayload(ok, ras));
    if (!copied) {
      toast.error("Clipboard ditolak browser. Izinkan akses clipboard lalu coba lagi.");
      return;
    }
    setList((l) => l.map((x) => (ok.some((o) => o.id === x.id) ? { ...x, status: "disalin" } : x)));
    toast.success(
      `${ok.length} progres disalin ke clipboard! Di e-Kinerja BKN, klik bookmark “⚡ Isi e-Kinerja”.`,
    );
  };

  const set = (k: keyof Progres) => (e: { target: { value: string } }) =>
    setForm({ ...form, [k]: e.target.value });
  const formRa = raById(form.rencanaAksiId);

  return (
    <div className="min-h-screen">
      <header className="bg-header text-primary-foreground">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 py-8 sm:py-10">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-xs sm:text-sm font-semibold uppercase tracking-widest text-accent">
              e-Kinerja BKN
            </p>
            <div className="flex items-center gap-2 text-xs sm:text-sm">
              <span className="opacity-80 max-w-[180px] sm:max-w-none truncate">{email}</span>
              <Button
                size="sm"
                variant="secondary"
                onClick={() => (onExitLocal ? onExitLocal() : supabase.auth.signOut())}
              >
                <LogOut className="size-3.5" /> Keluar
              </Button>
            </div>
          </div>
          <h1 className="mt-2 font-display text-3xl sm:text-4xl md:text-5xl">
            Asisten Progres Harian
          </h1>
          <p className="mt-2 sm:mt-3 max-w-2xl text-xs sm:text-base opacity-80">
            Rencana Aksi → Progress Harian → Realisasi & Bukti Dukung Timemark, dicek dulu lalu
            diisi otomatis.
          </p>

          {/* Mobile Tab Switcher (< lg) */}
          <div className="mt-6 flex lg:hidden gap-2 border-t border-white/20 pt-4">
            <button
              type="button"
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-md text-xs font-semibold transition-colors ${
                mobileTab === "progres"
                  ? "bg-white text-slate-900 shadow"
                  : "bg-white/10 text-white hover:bg-white/20"
              }`}
              onClick={() => setMobileTab("progres")}
            >
              <ListTodo className="size-3.5" />
              Progres Hari Ini ({harian.length})
            </button>
            <button
              type="button"
              className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-md text-xs font-semibold transition-colors ${
                mobileTab === "input"
                  ? "bg-white text-slate-900 shadow"
                  : "bg-white/10 text-white hover:bg-white/20"
              }`}
              onClick={() => setMobileTab("input")}
            >
              <Plus className="size-3.5" />
              Input & Form
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto grid max-w-6xl gap-6 px-4 sm:px-6 py-6 sm:py-8 lg:grid-cols-[380px_1fr]">
        <aside className={`space-y-6 ${mobileTab === "input" ? "block" : "hidden lg:block"}`}>
          <section className="rounded-lg border bg-card p-4 sm:p-5 shadow-xs">
            <h2 className="font-display text-lg sm:text-xl">1. Rencana Aksi</h2>
            <div className="mt-3 space-y-2">
              <Input
                placeholder="Nama rencana aksi (sama persis dengan e-Kinerja)"
                value={raForm.nama}
                onChange={(e) => setRaForm({ ...raForm, nama: e.target.value })}
              />
              <div className="grid grid-cols-3 gap-2">
                <select
                  className="col-span-3 h-9 rounded-md border bg-background px-2 text-sm"
                  value={raForm.jenis}
                  onChange={(e) => setRaForm({ ...raForm, jenis: e.target.value as JenisTarget })}
                >
                  <option>Trajectory</option>
                  <option>Non - Trajectory</option>
                </select>
                <Input
                  type="number"
                  min={1}
                  value={raForm.target}
                  onChange={(e) => setRaForm({ ...raForm, target: Number(e.target.value) })}
                />
                <Input
                  className="col-span-2"
                  placeholder="Satuan"
                  disabled={raForm.jenis === "Non - Trajectory"}
                  value={raForm.jenis === "Non - Trajectory" ? "Kegiatan" : raForm.satuan}
                  onChange={(e) => setRaForm({ ...raForm, satuan: e.target.value })}
                />
              </div>
              <Button variant="secondary" className="w-full" onClick={addRa}>
                <Plus className="size-4" /> Tambah rencana aksi
              </Button>
              <ul className="space-y-1 text-sm max-h-48 overflow-y-auto">
                {ras.map((r) => (
                  <li
                    key={r.id}
                    className="flex items-start justify-between gap-2 rounded bg-muted/70 p-2"
                  >
                    <span className="text-xs sm:text-sm">
                      {r.nama}{" "}
                      <span className="text-muted-foreground">
                        ({r.jenis}) · {r.target} {r.satuan}
                      </span>
                    </span>
                    <button
                      type="button"
                      aria-label="Hapus"
                      className="text-muted-foreground hover:text-destructive p-0.5"
                      onClick={() => setRas((x) => x.filter((y) => y.id !== r.id))}
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </section>

          <section className="rounded-lg border bg-card p-4 sm:p-5 shadow-xs">
            <h2 className="font-display text-lg sm:text-xl">2. Tambah Progress Harian</h2>
            <div className="mt-3 space-y-3">
              <div>
                <Label>Rencana aksi</Label>
                <select
                  className="h-9 w-full rounded-md border bg-background px-2 text-sm"
                  value={form.rencanaAksiId}
                  onChange={set("rencanaAksiId")}
                >
                  <option value="">— pilih rencana aksi —</option>
                  {ras.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.nama} ({r.jenis})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label>Tanggal kegiatan</Label>
                <Input type="date" value={form.tanggal} onChange={set("tanggal")} />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label>Jam mulai</Label>
                  <Input type="time" value={form.jamMulai} onChange={set("jamMulai")} />
                </div>
                <div>
                  <Label>Jam selesai</Label>
                  <Input type="time" value={form.jamSelesai} onChange={set("jamSelesai")} />
                </div>
              </div>
              <div>
                <Label>Rencana kegiatan harian</Label>
                <Textarea
                  rows={3}
                  placeholder="Deskripsi kegiatan harian sesuai SKP..."
                  value={form.kegiatan}
                  onChange={set("kegiatan")}
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <div>
                  <Label>Realisasi</Label>
                  <Input
                    value={form.realisasi}
                    onChange={set("realisasi")}
                    placeholder={formRa?.satuan ?? "Angka"}
                  />
                </div>
                <div className="col-span-2">
                  <Label>Bukti dukung (link)</Label>
                  <Input
                    value={form.linkBukti}
                    onChange={set("linkBukti")}
                    placeholder="https://drive.google.com/..."
                  />
                </div>
              </div>
              <BuktiUpload
                keterangan={form.kegiatan}
                link={form.linkBukti}
                onLink={(l) => setForm((f) => ({ ...f, linkBukti: l }))}
              />
              {formRa?.jenis === "Non - Trajectory" && (
                <label className="flex items-center gap-2 text-xs sm:text-sm">
                  <input
                    type="checkbox"
                    checked={form.selesai}
                    onChange={(e) => setForm({ ...form, selesai: e.target.checked })}
                  />{" "}
                  Selesai rencana aksi periode ini
                </label>
              )}
              <Button className="w-full" onClick={add}>
                <Plus className="size-4" /> Tambah ke Hari Ini
              </Button>
            </div>
          </section>

          <section className="rounded-lg border bg-card p-4 sm:p-5 shadow-xs">
            <h2 className="font-display text-lg sm:text-xl">Excel</h2>
            <div className="mt-3 grid gap-2">
              <input
                ref={fileRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                hidden
                onChange={(e) => onImport(e.target.files?.[0])}
              />
              <Button variant="secondary" onClick={() => fileRef.current?.click()}>
                <FileUp className="size-4" /> Impor dari Excel
              </Button>
              <Button
                variant="outline"
                onClick={() => exportExcel([], ras, "template-progres-harian.xlsx")}
              >
                <FileDown className="size-4" /> Unduh template
              </Button>
              <Button
                variant="outline"
                onClick={() => exportExcel(list, ras, "progres-harian.xlsx")}
              >
                <FileDown className="size-4" /> Ekspor semua
              </Button>
            </div>
          </section>
        </aside>

        <div className={`space-y-6 ${mobileTab === "progres" ? "block" : "hidden lg:block"}`}>
          <section className="rounded-lg border bg-card shadow-xs">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b p-4 sm:p-5">
              <div>
                <div className="flex items-center gap-2">
                  <Clock className="size-4 text-primary" />
                  <h2 className="font-display text-lg sm:text-xl">Progres Harian</h2>
                </div>
                <div className="mt-1 flex items-center gap-2">
                  <p
                    className={
                      total >= TARGET_MENIT_HARIAN
                        ? "text-xs sm:text-sm font-semibold text-emerald-600"
                        : "text-xs sm:text-sm text-amber-600 font-medium"
                    }
                  >
                    {fmtMenit(total)} / {fmtMenit(TARGET_MENIT_HARIAN)} (
                    {Math.round((total / TARGET_MENIT_HARIAN) * 100)}%)
                  </p>
                  {total >= TARGET_MENIT_HARIAN && (
                    <Badge className="bg-emerald-100 text-emerald-800 border-emerald-300 text-[10px]">
                      Target Tercapai
                    </Badge>
                  )}
                </div>
                <div className="mt-1.5 w-44 sm:w-60 bg-muted rounded-full h-1.5 overflow-hidden">
                  <div
                    className={`h-full transition-all duration-300 ${
                      total >= TARGET_MENIT_HARIAN ? "bg-emerald-500" : "bg-amber-500"
                    }`}
                    style={{
                      width: `${Math.min(100, Math.round((total / TARGET_MENIT_HARIAN) * 100))}%`,
                    }}
                  />
                </div>
              </div>

              <div className="flex flex-wrap sm:flex-nowrap items-center gap-2">
                <Input
                  type="date"
                  className="w-36 sm:w-44 text-xs sm:text-sm"
                  value={hari}
                  onChange={(e) => setHari(e.target.value)}
                />
                <Button onClick={kirim} className="gap-1.5 text-xs sm:text-sm">
                  <Send className="size-3.5 sm:size-4" /> Salin untuk e-Kinerja
                </Button>
              </div>
            </div>

            {harian.length === 0 ? (
              <div className="p-10 text-center text-muted-foreground space-y-2">
                <p>Tidak ada kegiatan di tanggal ini.</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="text-xs lg:hidden"
                  onClick={() => setMobileTab("input")}
                >
                  <Plus className="size-3.5" /> Tambah Kegiatan
                </Button>
              </div>
            ) : (
              <ul className="divide-y">
                {harian.map((p) => {
                  const ra = raById(p.rencanaAksiId);
                  const errs = validasi(p, list, ra);
                  return (
                    <li
                      key={p.id}
                      className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4 p-4 sm:p-5 hover:bg-muted/30 transition-colors"
                    >
                      <div className="w-24 shrink-0 text-xs sm:text-sm font-semibold font-mono text-slate-700">
                        {p.jamMulai}–{p.jamSelesai}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-[11px] sm:text-xs font-semibold uppercase tracking-wide text-primary">
                          {ra ? `${ra.nama} (${ra.jenis})` : "Rencana aksi belum dipilih"}
                        </p>
                        <p className="mt-1 text-sm font-medium">{p.kegiatan}</p>
                        {(p.realisasi || p.linkBukti) && (
                          <p className="mt-1 truncate text-xs text-muted-foreground">
                            Realisasi: {p.realisasi || "-"} {ra?.satuan} · {p.linkBukti}
                          </p>
                        )}
                        {errs.length > 0 && (
                          <p className="mt-1 text-xs text-destructive font-medium">
                            {errs.join(" · ")}
                          </p>
                        )}
                      </div>
                      <div className="flex shrink-0 items-center sm:flex-col sm:items-end justify-between sm:justify-center gap-2 pt-2 sm:pt-0 border-t sm:border-0 border-border/40">
                        {errs.length ? (
                          <Badge variant="destructive" className="text-[10px]">
                            Perlu diperbaiki
                          </Badge>
                        ) : p.status === "terverifikasi" ? (
                          <Badge className="bg-emerald-600 text-white font-medium flex items-center gap-1 text-[10px]">
                            <Check className="size-3" /> Tersimpan di BKN
                          </Badge>
                        ) : p.status === "disalin" || p.status === "terkirim" ? (
                          <Badge
                            variant="outline"
                            className="border-amber-500/50 text-amber-700 bg-amber-500/10 font-medium text-[10px]"
                          >
                            Siap Diisi (Disalin)
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="text-[10px]">
                            Draft
                          </Badge>
                        )}

                        <div className="flex items-center gap-1">
                          {p.status !== "terverifikasi" && !errs.length && (
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 px-2 text-xs text-emerald-700 hover:text-emerald-800 hover:bg-emerald-50"
                              title="Tandai bahwa progres ini sudah berhasil disimpan di e-Kinerja BKN"
                              onClick={() =>
                                setList((l) =>
                                  l.map((x) =>
                                    x.id === p.id ? { ...x, status: "terverifikasi" } : x,
                                  ),
                                )
                              }
                            >
                              <CheckCircle2 className="size-3.5 mr-1" /> Selesai di BKN
                            </Button>
                          )}
                          <Button
                            size="icon"
                            variant="ghost"
                            className="size-7"
                            aria-label="Hapus"
                            onClick={() => setList((l) => l.filter((x) => x.id !== p.id))}
                          >
                            <Trash2 className="size-3.5 text-muted-foreground hover:text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>

          <section className="rounded-lg border border-accent bg-secondary/80 p-4 sm:p-5 shadow-xs">
            <h2 className="flex items-center gap-2 font-display text-lg sm:text-xl">
              <Bookmark className="size-5 text-accent-foreground" /> Pengisi Otomatis Bookmarklet
            </h2>
            <p className="mt-2 text-xs sm:text-sm text-muted-foreground">
              Seret atau simpan tombol ini ke bilah bookmark browser Anda (cukup sekali):
            </p>
            <a
              ref={bmRef}
              href="#"
              onClick={(e) => e.preventDefault()}
              className="mt-3 inline-flex items-center gap-2 rounded-md bg-accent px-4 py-2 text-xs sm:text-sm font-semibold text-accent-foreground shadow-xs active:scale-95 transition-transform"
            >
              ⚡ Isi e-Kinerja
            </a>
            <ol className="mt-4 list-decimal space-y-1.5 pl-5 text-xs sm:text-sm text-slate-700">
              <li>
                Pilih tanggal di atas, lalu klik <b>Salin untuk e-Kinerja</b>.
              </li>
              <li>
                Buka portal resmi e-Kinerja BKN: menu <b>SKP</b> → <b>Penilaian</b> →{" "}
                <b>Progress Harian</b>.
              </li>
              <li>
                Klik bookmark <b>⚡ Isi e-Kinerja</b> di browser Anda. Panel asisten akan muncul di
                pojok kanan bawah.
              </li>
              <li>
                Klik <b>Tambah Progress Harian</b> di e-Kinerja, lalu klik tombol <b>Isi</b> pada
                panel, periksa hasilnya, lalu klik <b>OK</b>.
              </li>
              <li>
                Setelah tersimpan di e-Kinerja BKN, klik <b>Selesai di BKN</b> di aplikasi ini untuk
                memverifikasi.
              </li>
            </ol>
            <div className="mt-4 pt-3 border-t border-accent/40 flex items-center justify-between">
              <a
                href="https://kinerja.bkn.go.id"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 text-xs sm:text-sm font-medium text-primary hover:underline"
              >
                Buka Portal e-Kinerja BKN <ExternalLink className="size-3.5" />
              </a>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
