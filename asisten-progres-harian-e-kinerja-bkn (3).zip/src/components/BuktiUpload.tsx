import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import {
  Camera,
  Paperclip,
  Loader2,
  Share2,
  HardDrive,
  RefreshCw,
  Download,
  Copy,
  MapPin,
  SwitchCamera,
  Check,
  X,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  completeDriveConnect,
  disconnectDrive,
  driveStatus,
  startDriveConnect,
  uploadBukti,
} from "@/lib/drive.functions";
import { ambilLokasi, blobToBase64, stempelFoto, type Lokasi } from "@/lib/timemark";

function waitForOAuth(popup: Window) {
  return new Promise<string | null>((resolve, reject) => {
    const cleanup = () => {
      window.removeEventListener("message", onMsg);
      clearInterval(poll);
    };
    const onMsg = (e: MessageEvent) => {
      const t = e.data?.type;
      if (
        e.origin !== window.location.origin ||
        e.source !== popup ||
        e.data?.connectorId !== "google_drive"
      )
        return;
      if (t !== "appUserConnectorOAuthComplete" && t !== "appUserConnectorOAuthFailed") return;
      cleanup();
      if (t === "appUserConnectorOAuthComplete")
        resolve(typeof e.data.code === "string" ? e.data.code : null);
      else reject(new Error("Gagal menyambungkan Google Drive"));
    };
    window.addEventListener("message", onMsg);
    const poll = window.setInterval(() => {
      if (popup.closed) {
        cleanup();
        reject(new Error("Jendela Google ditutup sebelum selesai"));
      }
    }, 500);
  });
}

export function BuktiUpload({
  keterangan,
  link,
  onLink,
}: {
  keterangan: string;
  link: string;
  onLink: (l: string) => void;
}) {
  const camInput = useRef<HTMLInputElement>(null);
  const docInput = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);

  const [busy, setBusy] = useState("");
  const [preview, setPreview] = useState("");
  const [previewBlob, setPreviewBlob] = useState<Blob | null>(null);
  const [previewFileName, setPreviewFileName] = useState("bukti-dukung-stempel.jpg");
  const [connected, setConnected] = useState<boolean | null>(null);

  // Live Camera state
  const [isLiveCamOpen, setIsLiveCamOpen] = useState(false);
  const [facingMode, setFacingMode] = useState<"environment" | "user">("environment");
  const [mediaStream, setMediaStream] = useState<MediaStream | null>(null);
  const [cameraLoading, setCameraLoading] = useState(false);
  const [cameraError, setCameraError] = useState("");
  const [lokasi, setLokasi] = useState<Lokasi | null>(null);
  const [loadingGps, setLoadingGps] = useState(false);
  const [instansi, setInstansi] = useState("e-Kinerja BKN");
  const [copiedImage, setCopiedImage] = useState(false);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("ekinerja_instansi");
      if (saved) setInstansi(saved);
    }
  }, []);

  useEffect(() => {
    driveStatus()
      .then((r) => setConnected(r.connected))
      .catch(() => setConnected(false));
  }, []);

  // Save instansi preference
  const updateInstansi = (val: string) => {
    setInstansi(val);
    if (typeof window !== "undefined") {
      localStorage.setItem("ekinerja_instansi", val);
    }
  };

  // Robust camera initializer with multi-level fallback
  const startCamera = async (facing = facingMode) => {
    setCameraLoading(true);
    setCameraError("");

    if (mediaStream) {
      mediaStream.getTracks().forEach((t) => t.stop());
      setMediaStream(null);
    }

    if (!navigator?.mediaDevices?.getUserMedia) {
      setCameraError(
        "Peramban Anda tidak mengizinkan akses kamera langsung. Silakan gunakan tombol 'Pilih File Foto' di bawah.",
      );
      setCameraLoading(false);
      return;
    }

    let stream: MediaStream | null = null;
    try {
      // Coba 1: Kamera belakang atau depan sesuai facingMode
      stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: facing },
          width: { ideal: 1920 },
          height: { ideal: 1080 },
        },
        audio: false,
      });
    } catch {
      // Coba 2: Kamera default (biasa untuk laptop / PC desktop tanpa kamera belakang)
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false,
        });
      } catch (err) {
        const msg = err instanceof Error ? err.name : String(err);
        setCameraError(
          `Kamera tidak dapat diakses (${msg}). Pastikan webcam terpasang dan izin kamera telah diizinkan pada peramban Anda, atau gunakan tombol 'Pilih File Foto' di bawah.`,
        );
        setCameraLoading(false);
        return;
      }
    }

    if (stream) {
      setMediaStream(stream);
      setCameraLoading(false);
    }
  };

  // Open live camera dialog
  const bukaKameraLangsung = () => {
    setIsLiveCamOpen(true);
    setLoadingGps(true);
    ambilLokasi()
      .then((l) => setLokasi(l))
      .catch(() => {})
      .finally(() => setLoadingGps(false));

    startCamera(facingMode);
  };

  // Stop live camera stream
  const tutupKameraLangsung = () => {
    if (mediaStream) {
      mediaStream.getTracks().forEach((t) => t.stop());
      setMediaStream(null);
    }
    setCameraError("");
    setCameraLoading(false);
    setIsLiveCamOpen(false);
  };

  // Switch between front and back camera
  const gantiKamera = async () => {
    const nextFacing = facingMode === "environment" ? "user" : "environment";
    setFacingMode(nextFacing);
    startCamera(nextFacing);
  };

  // Snapshot from live video stream
  const potretLive = async () => {
    if (!videoRef.current) return;
    try {
      setBusy("Menambahkan stempel Timemark…");
      const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
      const name = `bukti-${stamp}.jpg`;

      // Capture direct from HTMLVideoElement
      const blob = await stempelFoto(videoRef.current, keterangan, lokasi, new Date(), instansi);

      tutupKameraLangsung();

      setPreviewBlob(blob);
      setPreviewFileName(name);
      setPreview(URL.createObjectURL(blob));

      if (connected) {
        setBusy("Mengunggah ke Google Drive Anda…");
        const r = await uploadBukti({
          data: { name, mimeType: "image/jpeg", base64: await blobToBase64(blob) },
        });
        if ("needConnect" in r) {
          setConnected(false);
          toast.error("Sambungkan ulang Google Drive Anda dulu");
          return;
        }
        onLink(r.link);
        toast.success("Foto berstempel disimpan ke Google Drive Anda!");
      } else {
        toast.success("Foto berstempel GPS berhasil dibuat!");
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Gagal mengambil foto");
    } finally {
      setBusy("");
    }
  };

  const sambung = async () => {
    const popup = window.open("", "lovable-oauth", "width=600,height=720");
    if (!popup) {
      toast.error("Popup diblokir. Izinkan popup lalu coba lagi.");
      return;
    }
    try {
      setBusy("Menyambungkan Google Drive…");
      const { authorizationUrl } = await startDriveConnect();
      const done = waitForOAuth(popup);
      popup.location.href = authorizationUrl;
      const code = await done;
      if (code) await completeDriveConnect({ data: { code } });
      setConnected(true);
      toast.success("Google Drive Anda tersambung");
    } catch (e) {
      popup.close();
      toast.error(e instanceof Error ? e.message : "Gagal menyambungkan");
    } finally {
      setBusy("");
    }
  };

  const putus = async () => {
    await disconnectDrive();
    setConnected(false);
    toast.success("Google Drive diputus");
  };

  const prosesFile = async (f?: File) => {
    if (!f) return;
    try {
      let blob: Blob = f;
      let name = f.name;
      const stamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);

      if (f.type.startsWith("image/")) {
        setBusy("Mengambil lokasi GPS…");
        const lok = lokasi || (await ambilLokasi());
        if (!lok) toast.warning("Lokasi tidak didapat. Izinkan akses lokasi agar GPS tercetak.");
        setBusy("Menambahkan stempel Timemark…");
        blob = await stempelFoto(f, keterangan, lok, new Date(), instansi);
        name = `bukti-${stamp}.jpg`;
        setPreviewBlob(blob);
        setPreviewFileName(name);
        setPreview(URL.createObjectURL(blob));
      }

      if (connected) {
        setBusy("Mengunggah ke Google Drive Anda…");
        const r = await uploadBukti({
          data: { name, mimeType: blob.type || f.type, base64: await blobToBase64(blob) },
        });
        if ("needConnect" in r) {
          setConnected(false);
          toast.error("Sambungkan ulang Google Drive Anda dulu");
          return;
        }
        onLink(r.link);
        toast.success("Link Google Drive Anda sudah terisi di Bukti Dukung");
      } else {
        toast.success("Bukti berstempel GPS siap. Silakan unduh atau tautkan link Drive.");
      }
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Upload gagal");
    } finally {
      setBusy("");
      if (camInput.current) camInput.current.value = "";
      if (docInput.current) docInput.current.value = "";
    }
  };

  const share = async () => {
    if (navigator.share)
      await navigator.share({ title: "Bukti dukung", url: link }).catch(() => {});
    else {
      await navigator.clipboard.writeText(link).catch(() => {});
      toast.success("Link disalin");
    }
  };

  const salinFotoClipboard = async () => {
    if (!previewBlob) return;
    try {
      const pngBlob = await new Promise<Blob>((resolve) => {
        const img = new Image();
        img.src = preview;
        img.onload = () => {
          const cvs = document.createElement("canvas");
          cvs.width = img.naturalWidth;
          cvs.height = img.naturalHeight;
          const cx = cvs.getContext("2d")!;
          cx.drawImage(img, 0, 0);
          cvs.toBlob((b) => resolve(b || previewBlob), "image/png");
        };
      });
      await navigator.clipboard.write([new ClipboardItem({ "image/png": pngBlob })]);
      setCopiedImage(true);
      toast.success("Foto berstempel disalin ke clipboard!");
      setTimeout(() => setCopiedImage(false), 2000);
    } catch {
      toast.error("Gunakan tombol 'Unduh foto berstempel' jika peramban membatasi salin gambar.");
    }
  };

  return (
    <div className="space-y-3">
      {/* Native file inputs for fallback / direct selection */}
      <input
        ref={camInput}
        type="file"
        accept="image/*"
        capture="environment"
        hidden
        onChange={(e) => prosesFile(e.target.files?.[0])}
      />
      <input
        ref={docInput}
        type="file"
        accept="image/*,application/pdf,.doc,.docx,.xls,.xlsx"
        hidden
        onChange={(e) => prosesFile(e.target.files?.[0])}
      />

      {/* Action buttons */}
      <div className="grid grid-cols-2 gap-2">
        <Button
          type="button"
          variant="secondary"
          className="flex items-center justify-center gap-2"
          disabled={!!busy}
          onClick={bukaKameraLangsung}
        >
          <Camera className="size-4 text-primary" /> Kamera Timemark
        </Button>
        <Button
          type="button"
          variant="outline"
          className="flex items-center justify-center gap-2"
          disabled={!!busy}
          onClick={() => docInput.current?.click()}
        >
          <Paperclip className="size-4" /> Pilih Dokumen
        </Button>
      </div>

      {/* Google Drive Status Bar */}
      <div className="flex items-center justify-between rounded-md border border-border/60 bg-muted/40 px-3 py-1.5 text-xs text-muted-foreground">
        {connected ? (
          <span className="flex items-center gap-1.5 font-medium text-emerald-600">
            <span className="inline-block size-2 rounded-full bg-emerald-500 animate-pulse" />
            Google Drive Tersambung
          </span>
        ) : (
          <span className="flex items-center gap-1.5">
            <HardDrive className="size-3.5" />
            Google Drive: Tidak tersambung
          </span>
        )}
        {connected ? (
          <button
            type="button"
            className="underline hover:text-destructive transition-colors"
            onClick={putus}
          >
            Putuskan
          </button>
        ) : (
          <button
            type="button"
            className="font-medium text-primary underline hover:text-primary/80 transition-colors"
            disabled={!!busy}
            onClick={sambung}
          >
            Sambungkan Drive
          </button>
        )}
      </div>

      {busy && (
        <p className="flex items-center gap-2 text-sm text-primary font-medium animate-pulse">
          <Loader2 className="size-4 animate-spin" /> {busy}
        </p>
      )}

      {/* Image Preview & Quick Actions */}
      {preview && (
        <div className="space-y-2 rounded-lg border bg-card p-2.5 shadow-sm">
          <div className="relative overflow-hidden rounded-md border bg-black">
            <img
              src={preview}
              alt="Pratinjau bukti berstempel"
              className="w-full object-contain max-h-64"
            />
            <div className="absolute top-2 right-2">
              <Button
                type="button"
                size="icon"
                variant="destructive"
                className="size-7 rounded-full shadow"
                onClick={() => {
                  setPreview("");
                  setPreviewBlob(null);
                }}
              >
                <X className="size-3.5" />
              </Button>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <a
              href={preview}
              download={previewFileName}
              className="inline-flex h-8 items-center gap-1.5 rounded-md border border-input bg-background px-3 text-xs font-medium hover:bg-accent hover:text-accent-foreground"
            >
              <Download className="size-3.5" /> Unduh Foto
            </a>
            <Button
              type="button"
              variant="outline"
              size="sm"
              className="h-8 text-xs gap-1.5"
              onClick={salinFotoClipboard}
            >
              {copiedImage ? (
                <Check className="size-3.5 text-emerald-600" />
              ) : (
                <Copy className="size-3.5" />
              )}
              {copiedImage ? "Disalin!" : "Salin Foto"}
            </Button>
            {link && (
              <Button
                type="button"
                size="sm"
                variant="ghost"
                className="h-8 text-xs gap-1.5"
                onClick={share}
              >
                <Share2 className="size-3.5" /> Bagikan Link
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Interactive Live Camera Viewfinder Dialog */}
      <Dialog
        open={isLiveCamOpen}
        onOpenChange={(open) => {
          if (!open) tutupKameraLangsung();
        }}
      >
        <DialogContent className="max-w-xl p-0 overflow-hidden bg-slate-950 text-white border-slate-800">
          <DialogHeader className="p-4 pb-2 bg-slate-900 border-b border-slate-800">
            <div className="flex items-center justify-between">
              <DialogTitle className="flex items-center gap-2 text-base font-semibold text-white">
                <Camera className="size-4 text-yellow-400" /> Kamera Timemark e-Kinerja
              </DialogTitle>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="size-8 text-slate-400 hover:text-white"
                onClick={tutupKameraLangsung}
              >
                <X className="size-4" />
              </Button>
            </div>
            <DialogDescription className="text-xs text-slate-400">
              Foto otomatis dilengkapi stempel waktu, lokasi GPS, dan keterangan kegiatan.
            </DialogDescription>
          </DialogHeader>

          {/* Viewfinder area */}
          <div className="relative w-full aspect-video md:aspect-[4/3] bg-black flex items-center justify-center overflow-hidden">
            {cameraError ? (
              <div className="p-6 text-center text-slate-300 space-y-3 max-w-md z-10">
                <AlertCircle className="size-10 text-amber-400 mx-auto" />
                <p className="text-xs leading-relaxed text-slate-200">{cameraError}</p>
                <div className="flex flex-col sm:flex-row gap-2 justify-center pt-2">
                  <Button
                    type="button"
                    size="sm"
                    variant="secondary"
                    className="text-xs"
                    onClick={() => startCamera(facingMode)}
                  >
                    <RefreshCw className="size-3.5 mr-1.5" /> Coba Sambungkan Lagi
                  </Button>
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    className="text-xs border-slate-700 bg-slate-800 text-slate-200 hover:bg-slate-700 hover:text-white"
                    onClick={() => {
                      tutupKameraLangsung();
                      docInput.current?.click();
                    }}
                  >
                    <Paperclip className="size-3.5 mr-1.5" /> Pilih File Foto
                  </Button>
                </div>
              </div>
            ) : cameraLoading ? (
              <div className="flex flex-col items-center gap-2 text-slate-400 text-xs">
                <Loader2 className="size-8 animate-spin text-yellow-400" />
                <span>Menghubungkan ke kamera perangkat...</span>
              </div>
            ) : (
              <video
                ref={(el) => {
                  if (el && mediaStream && el.srcObject !== mediaStream) {
                    el.srcObject = mediaStream;
                    el.play().catch(() => {});
                  }
                  (videoRef as { current: HTMLVideoElement | null }).current = el;
                }}
                playsInline
                autoPlay
                muted
                className={`w-full h-full object-cover ${facingMode === "user" ? "scale-x-[-1]" : ""}`}
              />
            )}

            {/* Grid overlay */}
            {!cameraError && (
              <div className="pointer-events-none absolute inset-0 grid grid-cols-3 grid-rows-3 opacity-20">
                <div className="border-r border-b border-white" />
                <div className="border-r border-b border-white" />
                <div className="border-b border-white" />
                <div className="border-r border-b border-white" />
                <div className="border-r border-b border-white" />
                <div className="border-b border-white" />
                <div className="border-r border-white" />
                <div className="border-r border-white" />
                <div />
              </div>
            )}

            {/* Live GPS badge overlay */}
            <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-md rounded-md px-2.5 py-1 text-[11px] font-mono text-slate-200 border border-white/10 flex items-center gap-1.5">
              <MapPin
                className={`size-3 ${lokasi ? "text-emerald-400" : "text-amber-400 animate-pulse"}`}
              />
              {loadingGps ? (
                <span>Mencari sinyal GPS…</span>
              ) : lokasi ? (
                <span>
                  {lokasi.lat.toFixed(4)}, {lokasi.lon.toFixed(4)} (±{Math.round(lokasi.acc)}m)
                </span>
              ) : (
                <span>GPS tidak tersedia</span>
              )}
            </div>

            {/* Camera switch button */}
            {!cameraError && (
              <button
                type="button"
                className="absolute top-3 right-3 bg-black/60 backdrop-blur-md p-2 rounded-full text-white hover:bg-black/80 border border-white/20 transition-all active:scale-95"
                onClick={gantiKamera}
                title="Ganti kamera depan/belakang"
              >
                <SwitchCamera className="size-4" />
              </button>
            )}

            {/* Live Timemark preview banner at bottom of viewfinder */}
            <div className="pointer-events-none absolute bottom-0 inset-x-0 bg-gradient-to-t from-slate-950/90 via-slate-900/60 to-transparent p-3 pt-6 text-left">
              <div className="flex items-center gap-2">
                <span className="text-xl font-bold font-mono text-white tracking-wide">
                  {new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })}
                </span>
                <span className="h-4 w-1 bg-yellow-400 rounded-sm" />
                <span className="text-xs text-slate-200 font-medium">
                  {new Date().toLocaleDateString("id-ID", {
                    weekday: "long",
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </span>
              </div>
              <p className="mt-0.5 text-[11px] text-yellow-300 truncate max-w-full font-medium">
                {instansi} • {keterangan || "Kegiatan e-Kinerja"}
              </p>
            </div>
          </div>

          {/* Camera controls footer */}
          <div className="p-4 bg-slate-900 border-t border-slate-800 space-y-3">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 whitespace-nowrap">Instansi/OPD:</span>
              <Input
                value={instansi}
                onChange={(e) => updateInstansi(e.target.value)}
                placeholder="Contoh: BKPSDM / Dinas Pendidikan"
                className="h-8 text-xs bg-slate-950 border-slate-700 text-white"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="text-xs text-slate-400 hover:text-white"
                onClick={() => {
                  tutupKameraLangsung();
                  docInput.current?.click();
                }}
              >
                Pilih File Dokumen/Foto
              </Button>

              {/* Shutter button */}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  disabled={!mediaStream || !!cameraError || cameraLoading}
                  className="size-14 rounded-full border-4 border-white bg-red-600 hover:bg-red-500 disabled:opacity-40 disabled:cursor-not-allowed active:scale-95 shadow-lg flex items-center justify-center transition-transform"
                  onClick={potretLive}
                  title="Ambil Foto Berstempel"
                >
                  <div className="size-10 rounded-full border-2 border-white/50 bg-red-500" />
                </button>
              </div>

              <Button
                type="button"
                variant="outline"
                size="sm"
                className="text-xs border-slate-700 bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white"
                onClick={tutupKameraLangsung}
              >
                Batal
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
