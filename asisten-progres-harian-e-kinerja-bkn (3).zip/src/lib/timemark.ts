export type Lokasi = { lat: number; lon: number; acc: number; alamat: string };

export function ambilLokasi(): Promise<Lokasi | null> {
  return new Promise((res) => {
    if (!navigator.geolocation) return res(null);
    navigator.geolocation.getCurrentPosition(
      async (p) => {
        const { latitude: lat, longitude: lon, accuracy: acc } = p.coords;
        let alamat = "";
        try {
          const r = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&accept-language=id`,
          );
          alamat = ((await r.json()) as { display_name?: string }).display_name ?? "";
        } catch {
          /* tanpa alamat */
        }
        res({ lat, lon, acc, alamat });
      },
      () => res(null),
      { enableHighAccuracy: true, timeout: 15000 },
    );
  });
}

const HARI = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"];
const pad = (n: number) => String(n).padStart(2, "0");

function wrap(ctx: CanvasRenderingContext2D, text: string, max: number): string[] {
  const out: string[] = [];
  let line = "";
  for (const w of text.split(/\s+/)) {
    const t = line ? line + " " + w : w;
    if (ctx.measureText(t).width > max && line) {
      out.push(line);
      line = w;
    } else line = t;
  }
  if (line) out.push(line);
  return out.slice(0, 4);
}

export type StempelFotoInput = File | Blob | HTMLVideoElement | ImageBitmap;

/** Gambar stempel ala Timemark (jam, tanggal, alamat, GPS, keterangan) dan kembalikan JPEG. */
export async function stempelFoto(
  input: StempelFotoInput,
  ket: string,
  lok: Lokasi | null,
  now = new Date(),
  instansi = "e-Kinerja BKN",
): Promise<Blob> {
  let W = 1280;
  let H = 720;
  let drawSource: CanvasImageSource;

  if (typeof HTMLVideoElement !== "undefined" && input instanceof HTMLVideoElement) {
    W = input.videoWidth || 1280;
    H = input.videoHeight || 720;
    drawSource = input;
  } else {
    const img =
      typeof ImageBitmap !== "undefined" && input instanceof ImageBitmap
        ? input
        : await createImageBitmap(input as Blob);
    const scale = Math.min(1, 1920 / Math.max(img.width, img.height));
    W = Math.round(img.width * scale);
    H = Math.round(img.height * scale);
    drawSource = img;
  }

  const c = document.createElement("canvas");
  c.width = W;
  c.height = H;
  const ctx = c.getContext("2d")!;
  ctx.drawImage(drawSource, 0, 0, W, H);

  const u = Math.max(W, H) / 100; // unit
  const pd = u * 2.2;
  const maxW = W - pd * 2;
  const jam = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
  const tgl = `${pad(now.getDate())}-${pad(now.getMonth() + 1)}-${now.getFullYear()}`;
  const hari = HARI[now.getDay()]!;

  ctx.font = `${u * 1.6}px sans-serif`;
  const info: string[] = [];
  if (instansi && instansi.trim()) {
    info.push(`Instansi: ${instansi.trim()}`);
  }
  if (lok?.alamat) info.push(...wrap(ctx, lok.alamat, maxW));
  info.push(
    lok
      ? `GPS: ${lok.lat.toFixed(6)}, ${lok.lon.toFixed(6)} (±${Math.round(lok.acc)} m)`
      : "GPS: Lokasi tidak tersedia",
  );
  if (ket.trim()) info.push(...wrap(ctx, "Kegiatan: " + ket.trim(), maxW));

  const lh = u * 2.2;
  const jamH = u * 5.5;
  const boxH = pd + jamH + lh * (info.length + 0.5) + pd;
  const g = ctx.createLinearGradient(0, H - boxH * 1.35, 0, H);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(0.25, "rgba(15,23,42,0.65)");
  g.addColorStop(1, "rgba(15,23,42,0.92)");
  ctx.fillStyle = g;
  ctx.fillRect(0, H - boxH * 1.35, W, boxH * 1.35);

  let y = H - boxH + pd + jamH * 0.85;
  ctx.fillStyle = "#ffffff";
  ctx.textBaseline = "alphabetic";
  ctx.font = `bold ${jamH}px sans-serif`;
  ctx.fillText(jam, pd, y);

  const jw = ctx.measureText(jam).width;
  ctx.fillStyle = "#facc15"; // kuning khas timemark
  ctx.fillRect(pd + jw + u * 1.2, y - jamH * 0.78, u * 0.45, jamH * 0.85);

  ctx.fillStyle = "#ffffff";
  ctx.font = `bold ${u * 1.9}px sans-serif`;
  ctx.fillText(tgl, pd + jw + u * 2.4, y - jamH * 0.42);

  ctx.font = `${u * 1.6}px sans-serif`;
  ctx.fillStyle = "#e2e8f0";
  ctx.fillText(hari, pd + jw + u * 2.4, y - jamH * 0.04);

  y += lh * 1.2;
  ctx.font = `${u * 1.55}px sans-serif`;
  ctx.fillStyle = "#f8fafc";
  for (const l of info) {
    ctx.fillText(l, pd, y);
    y += lh;
  }

  return new Promise((r, j) =>
    c.toBlob((b) => (b ? r(b) : j(new Error("Gagal memproses foto"))), "image/jpeg", 0.9),
  );
}

export function blobToBase64(b: Blob): Promise<string> {
  return new Promise((r, j) => {
    const fr = new FileReader();
    fr.onload = () => r(String(fr.result).split(",")[1] ?? "");
    fr.onerror = () => j(fr.error);
    fr.readAsDataURL(b);
  });
}
