import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const GATEWAY = "https://connector-gateway.lovable.dev";
const CID = "google_drive";
const SCOPES = [
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/userinfo.profile",
  "https://www.googleapis.com/auth/drive.file",
];
const FOLDER = "Bukti Dukung e-Kinerja";
const MAX = 15 * 1024 * 1024;

export const driveStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { getConnectionKeyForUser } = await import("@/server/appUserConnections.server");
    return { connected: !!(await getConnectionKeyForUser(context.userId, CID)) };
  });

export const startDriveConnect = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const clientKey = process.env["GOOGLE_DRIVE_APP_USER_CONNECTOR_CLIENT_API_KEY"];
    if (!clientKey) throw new Error("Klien Google Drive belum diatur");
    const { authorizeAppUserOAuth } = await import("@/integrations/lovable/appUserConnector");
    const { getConnectionKeyForUser } = await import("@/server/appUserConnections.server");
    const request = getRequest();
    const url = new URL(request.url);
    const sandboxHost =
      url.hostname === "localhost" ? request.headers.get("x-forwarded-host") : null;
    const returnUrl = new URL(
      "/api/oauth/google/return",
      sandboxHost ? `https://${sandboxHost}` : url.origin,
    ).toString();
    const existing = await getConnectionKeyForUser(context.userId, CID);
    const { authorizationUrl } = await authorizeAppUserOAuth({
      gatewayBaseUrl: GATEWAY,
      connectorId: CID,
      appUserId: context.userId,
      clientAPIKey: clientKey,
      returnUrl,
      connectionAPIKey: existing ?? undefined,
      credentialsConfiguration: { scopes: SCOPES },
    });
    return { authorizationUrl };
  });

export const completeDriveConnect = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { code: string }) => {
    if (!d || typeof d.code !== "string" || !d.code) throw new Error("Kode kosong");
    return d;
  })
  .handler(async ({ data, context }) => {
    const { exchangeAppUserOAuthCode } = await import("@/integrations/lovable/appUserConnector");
    const { saveConnectionKeyForUser } = await import("@/server/appUserConnections.server");
    const { connectionAPIKey, connectorId } = await exchangeAppUserOAuthCode(GATEWAY, data.code);
    if (connectorId !== CID) throw new Error("Koneksi salah");
    await saveConnectionKeyForUser(context.userId, CID, connectionAPIKey);
    return { ok: true };
  });

export const disconnectDrive = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { disconnectAppUser } = await import("@/integrations/lovable/appUserConnector");
    const s = await import("@/server/appUserConnections.server");
    const key = await s.getConnectionKeyForUser(context.userId, CID);
    if (key)
      await disconnectAppUser({
        gatewayBaseUrl: GATEWAY,
        connectionAPIKey: key,
        connectorId: CID,
      }).catch(() => {});
    await s.deleteConnectionKeyForUser(context.userId, CID);
    return { ok: true };
  });

type In = { name: string; mimeType: string; base64: string };

export const uploadBukti = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: In) => {
    if (!d || typeof d.base64 !== "string" || !d.base64) throw new Error("File kosong");
    if (d.base64.length > MAX * 1.37) throw new Error("File terlalu besar (maks 15MB)");
    if (!/^(image\/|application\/pdf|application\/vnd|application\/msword)/.test(d.mimeType))
      throw new Error("Jenis file tidak didukung");
    return { name: String(d.name).slice(0, 120), mimeType: d.mimeType, base64: d.base64 };
  })
  .handler(async ({ data, context }) => {
    const { callAsAppUser, appUserReconnectRequired } =
      await import("@/integrations/lovable/appUserConnector");
    const { getConnectionKeyForUser } = await import("@/server/appUserConnections.server");
    const key = await getConnectionKeyForUser(context.userId, CID);
    if (!key) return { needConnect: true as const };
    const call = (path: string, init?: RequestInit) =>
      callAsAppUser({
        gatewayBaseUrl: GATEWAY,
        connectionAPIKey: key,
        connectorId: CID,
        path,
        init,
        requiredScopes: SCOPES,
      });

    // Cari / buat folder khusus di Drive pengguna
    const q = encodeURIComponent(
      `name='${FOLDER}' and mimeType='application/vnd.google-apps.folder' and trashed=false`,
    );
    const fr = await call(`/drive/v3/files?q=${q}&fields=files(id)`);
    if (await appUserReconnectRequired(fr)) return { needConnect: true as const };
    if (!fr.ok) throw new Error(`Gagal cek folder [${fr.status}]: ${await fr.text()}`);
    let folderId = ((await fr.json()) as { files: { id: string }[] }).files[0]?.id;
    if (!folderId) {
      const cr = await call(`/drive/v3/files?fields=id`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: FOLDER, mimeType: "application/vnd.google-apps.folder" }),
      });
      if (!cr.ok) throw new Error(`Gagal membuat folder [${cr.status}]: ${await cr.text()}`);
      folderId = ((await cr.json()) as { id: string }).id;
    }

    const bytes = Uint8Array.from(atob(data.base64), (c) => c.charCodeAt(0));
    const boundary = "b" + Math.random().toString(36).slice(2);
    const meta = JSON.stringify({ name: data.name, mimeType: data.mimeType, parents: [folderId] });
    const enc = new TextEncoder();
    const body = new Blob([
      enc.encode(
        `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${meta}\r\n--${boundary}\r\nContent-Type: ${data.mimeType}\r\n\r\n`,
      ),
      bytes,
      enc.encode(`\r\n--${boundary}--`),
    ]);
    const up = await call(`/upload/drive/v3/files?uploadType=multipart&fields=id,webViewLink`, {
      method: "POST",
      headers: { "Content-Type": `multipart/related; boundary=${boundary}` },
      body,
    });
    if (await appUserReconnectRequired(up)) return { needConnect: true as const };
    if (!up.ok) throw new Error(`Upload gagal [${up.status}]: ${await up.text()}`);
    const f = (await up.json()) as { id: string; webViewLink?: string };

    return { link: f.webViewLink ?? `https://drive.google.com/file/d/${f.id}/view` };
  });
