/* Runs inside kinerja.bkn.go.id (injected via bookmarklet). Must be self-contained:
   no imports, no outer variables — it is serialized with Function.toString(). */
export function ekinerjaFiller() {
  type Item = {
    rencanaAksi: string;
    tanggal: string;
    jamMulai: string;
    jamSelesai: string;
    kegiatan: string;
    realisasi: string;
    linkBukti: string;
    selesai: boolean;
  };
  const w = window as unknown as { __ekinPanel?: HTMLElement };
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
  const N = (s: string | null | undefined) => (s || "").toLowerCase().replace(/\s+/g, " ").trim();
  const visible = (e: Element) => (e as HTMLElement).offsetParent !== null;

  function dialog(): ParentNode {
    const ds = [
      ...document.querySelectorAll(
        "[role=dialog],.modal.show,.modal-dialog,.ant-modal,.el-dialog,.v-dialog",
      ),
    ].filter(visible);
    return (ds.pop() as HTMLElement) || document;
  }
  function fieldBox(root: ParentNode, label: string): HTMLElement | null {
    const all = [...root.querySelectorAll("label,div,span,p,b,strong,th,td")].filter(
      (e) => e.children.length <= 1 && N(e.textContent).startsWith(label),
    );
    for (const lab of all) {
      let p: HTMLElement | null = lab.parentElement;
      for (let i = 0; i < 4 && p; i++) {
        if (p.querySelector("input,textarea,select,.ant-select,.vs__selected-options,.el-select"))
          return p;
        p = p.parentElement;
      }
    }
    return null;
  }
  function setNative(el: HTMLInputElement | HTMLTextAreaElement, v: string) {
    const proto =
      el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
    Object.getOwnPropertyDescriptor(proto, "value")!.set!.call(el, v);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  const key = (el: Element, k: string) =>
    ["keydown", "keyup"].forEach((t) =>
      el.dispatchEvent(
        new KeyboardEvent(t, { key: k, code: k, keyCode: k === "Enter" ? 13 : 27, bubbles: true }),
      ),
    );

  async function fillText(root: ParentNode, label: string, v: string, picker = false) {
    if (!v) return true;
    const box = fieldBox(root, label);
    const el = box?.querySelector<HTMLInputElement | HTMLTextAreaElement>(
      "textarea,input:not([type=hidden]):not([type=checkbox])",
    );
    if (!el) return false;
    if (el.readOnly && !picker) return false;
    el.focus();
    el.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    el.click();
    await sleep(80);
    setNative(el, v);
    if (picker) {
      await sleep(80);
      key(el, "Enter");
      await sleep(60);
    }
    el.dispatchEvent(new Event("blur", { bubbles: true }));
    (document.body as HTMLElement).click?.();
    await sleep(60);
    return N(el.value) === N(v) || el.value.includes(v);
  }

  async function fillSelect(root: ParentNode, label: string, v: string) {
    if (!v) return true;
    const box = fieldBox(root, label);
    if (!box) return false;
    const native = box.querySelector("select");
    if (native) {
      const o = [...native.options].find((o) => N(o.text).includes(N(v)));
      if (!o) return false;
      native.value = o.value;
      native.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
    const trigger =
      box.querySelector<HTMLElement>(
        ".ant-select-selector,.vs__dropdown-toggle,.el-select,.multiselect,[role=combobox]",
      ) || box;
    trigger.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    trigger.click();
    await sleep(200);
    const search = box.querySelector<HTMLInputElement>("input:not([type=hidden])");
    if (search && !search.readOnly) {
      setNative(search, v.slice(0, 40));
      await sleep(500);
    }
    const opts = [
      ...document.querySelectorAll<HTMLElement>(
        ".ant-select-item-option,.vs__dropdown-option,.el-select-dropdown__item,.multiselect__option,[role=option]",
      ),
    ].filter(visible);
    const target = N(v);
    const hit =
      opts.find((o) => N(o.textContent).startsWith(target)) ||
      opts.find((o) => N(o.textContent).includes(target));
    if (!hit) {
      if (search) key(search, "Escape");
      return false;
    }
    hit.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    hit.click();
    await sleep(150);
    return true;
  }

  async function fill(it: Item) {
    const root = dialog();
    if (root === document) {
      alert("Buka dulu formulir Tambah/Edit Progress Harian di e-Kinerja.");
      return;
    }
    const res: [string, boolean][] = [];
    res.push(["Rencana Aksi", await fillSelect(root, "rencana aksi", it.rencanaAksi)]);
    res.push(["Tanggal Kegiatan", await fillText(root, "tanggal kegiatan", it.tanggal, true)]);
    res.push(["Jam Mulai", await fillText(root, "jam mulai", it.jamMulai, true)]);
    res.push(["Jam Selesai", await fillText(root, "jam selesai", it.jamSelesai, true)]);
    res.push([
      "Rencana Kegiatan Harian",
      await fillText(root, "rencana kegiatan harian", it.kegiatan),
    ]);
    if (fieldBox(root, "realisasi")) {
      res.push(["Realisasi", await fillText(root, "realisasi", it.realisasi)]);
      res.push(["Bukti Dukung", await fillText(root, "bukti dukung", it.linkBukti)]);
      const cb = fieldBox(root, "selesai rencana aksi")?.querySelector<HTMLInputElement>(
        "input[type=checkbox]",
      );
      if (cb && it.selesai && !cb.checked) cb.click();
    }
    const miss = res.filter(([, ok]) => !ok).map(([k]) => k);
    status(
      miss.length
        ? "⚠ Periksa manual: " + miss.join(", ")
        : "✓ Semua terisi. Periksa lalu klik OK.",
      !miss.length,
    );
  }

  let statusEl: HTMLElement;
  function status(t: string, ok: boolean) {
    statusEl.textContent = t;
    statusEl.style.color = ok ? "#15803d" : "#b45309";
  }

  async function start() {
    let txt = "";
    try {
      txt = await navigator.clipboard.readText();
    } catch {
      txt = prompt("Tempel data dari Asisten Progres Harian:") || "";
    }
    let data: { __progresHarian?: number; items?: Item[] };
    try {
      data = JSON.parse(txt);
    } catch {
      alert('Data tidak ditemukan. Klik "Kirim ke e-Kinerja" di aplikasi dulu.');
      return;
    }
    if (!data.__progresHarian || !data.items?.length) {
      alert("Data bukan progres harian.");
      return;
    }
    w.__ekinPanel?.remove();
    const p = document.createElement("div");
    w.__ekinPanel = p;
    p.style.cssText =
      "position:fixed;right:16px;bottom:16px;z-index:2147483647;width:340px;max-height:70vh;overflow:auto;background:#fff;border:2px solid #1e3a8a;border-radius:10px;box-shadow:0 10px 30px rgba(0,0,0,.25);font:13px system-ui,sans-serif;color:#0f172a";
    p.innerHTML =
      '<div style="background:#1e3a8a;color:#fff;padding:8px 12px;display:flex;justify-content:space-between;align-items:center"><b>Asisten Progres Harian</b><button data-x style="background:none;border:0;color:#fff;font-size:18px;cursor:pointer">×</button></div><div data-s style="padding:6px 12px;font-weight:600">Buka formulir, lalu klik Isi.</div><div data-l></div>';
    statusEl = p.querySelector("[data-s]")!;
    p.querySelector("[data-x]")!.addEventListener("click", () => p.remove());
    const list = p.querySelector("[data-l]")!;
    data.items.forEach((it, i) => {
      const row = document.createElement("div");
      row.style.cssText =
        "padding:8px 12px;border-top:1px solid #e2e8f0;display:flex;gap:8px;align-items:center";
      row.innerHTML = `<div style="flex:1;min-width:0"><div style="font-weight:600">${i + 1}. ${it.tanggal} · ${it.jamMulai}–${it.jamSelesai}</div><div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#475569"></div></div><button style="background:#16a34a;color:#fff;border:0;border-radius:6px;padding:6px 10px;cursor:pointer;font-weight:600">Isi</button>`;
      (row.querySelector("div div:nth-child(2)") as HTMLElement).textContent = it.kegiatan;
      row.querySelector("button")!.addEventListener("click", async (e) => {
        const b = e.currentTarget as HTMLButtonElement;
        b.textContent = "…";
        await fill(it);
        b.textContent = "✓ Isi";
        row.style.background = "#f0fdf4";
      });
      list.appendChild(row);
    });
  }
  void start();
}
