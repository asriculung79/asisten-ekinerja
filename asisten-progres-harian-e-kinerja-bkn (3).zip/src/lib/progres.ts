import * as XLSX from "xlsx";
import { ekinerjaFiller } from "./filler";

export type JenisTarget = "Trajectory" | "Non - Trajectory";

export type RencanaAksi = {
  id: string;
  nama: string;
  jenis: JenisTarget;
  target: number;
  satuan: string;
};

export type Progres = {
  id: string;
  rencanaAksiId: string;
  tanggal: string; // YYYY-MM-DD
  jamMulai: string; // HH:mm
  jamSelesai: string;
  kegiatan: string; // Rencana Kegiatan Harian
  realisasi: string;
  linkBukti: string;
  selesai: boolean; // Non-Trajectory: tandai rencana aksi selesai
  status: "draft" | "disalin" | "terverifikasi" | "terkirim";
};

/** Target jam kerja per hari di e-Kinerja: 7 jam 30 menit. */
export const TARGET_MENIT_HARIAN = 450;

export const KOLOM = [
  "Tanggal Kegiatan",
  "Jam Mulai",
  "Jam Selesai",
  "Rencana Aksi",
  "Rencana Kegiatan Harian",
  "Realisasi",
  "Bukti Dukung",
] as const;

export function load<T>(key: string): T[] {
  try {
    return JSON.parse(localStorage.getItem(key) || "[]");
  } catch {
    return [];
  }
}
export function save<T>(key: string, list: T[]) {
  localStorage.setItem(key, JSON.stringify(list));
}

export function newId() {
  return Math.random().toString(36).slice(2, 10);
}

const pad = (n: number) => String(n).padStart(2, "0");

export function normTanggal(v: unknown): string {
  if (v == null || v === "") return "";
  if (typeof v === "number") {
    const d = XLSX.SSF.parse_date_code(v);
    return `${d.y}-${pad(d.m)}-${pad(d.d)}`;
  }
  const s = String(v).trim();
  const m = s.match(/^(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})$/);
  if (m) return `${m[3]}-${pad(Number(m[2]))}-${pad(Number(m[1]))}`;
  return s.slice(0, 10);
}

export function normJam(v: unknown): string {
  if (v == null || v === "") return "";
  if (typeof v === "number") {
    const mins = Math.round((v % 1) * 24 * 60);
    return `${pad(Math.floor(mins / 60))}:${pad(mins % 60)}`;
  }
  const m = String(v)
    .trim()
    .match(/^(\d{1,2})[:.](\d{2})/);
  return m ? `${pad(Number(m[1]))}:${m[2]}` : String(v);
}

export const toMenit = (j: string) => {
  const [h, m] = j.split(":").map(Number);
  return (h ?? 0) * 60 + (m ?? 0);
};
export const durasi = (p: Pick<Progres, "jamMulai" | "jamSelesai">) =>
  Math.max(0, toMenit(p.jamSelesai) - toMenit(p.jamMulai));
export const fmtMenit = (m: number) => `${Math.floor(m / 60)} Jam ${m % 60} Menit`;

/** Problems e-Kinerja would reject or that make the report inaccurate. */
export function validasi(p: Progres, semua: Progres[], ra?: RencanaAksi): string[] {
  const e: string[] = [];
  if (!ra) e.push("Rencana aksi belum dipilih");
  if (!/^\d{4}-\d{2}-\d{2}$/.test(p.tanggal)) e.push("Tanggal tidak valid");
  if (!p.kegiatan.trim()) e.push("Rencana kegiatan harian kosong");
  if (toMenit(p.jamSelesai) <= toMenit(p.jamMulai)) e.push("Jam selesai harus setelah jam mulai");
  const bentrok = semua.some(
    (o) =>
      o.id !== p.id &&
      o.tanggal === p.tanggal &&
      toMenit(o.jamMulai) < toMenit(p.jamSelesai) &&
      toMenit(p.jamMulai) < toMenit(o.jamSelesai),
  );
  if (bentrok) e.push("Jam bertabrakan dengan kegiatan lain");
  if (p.linkBukti && !/^https?:\/\//i.test(p.linkBukti))
    e.push("Link bukti dukung harus diawali https://");
  return e;
}

export function rowToProgres(r: Record<string, unknown>, ras: RencanaAksi[]): Progres {
  const g = (...ks: string[]) => {
    const key = Object.keys(r).find((x) =>
      ks.some((k) => x.trim().toLowerCase() === k.toLowerCase()),
    );
    return key ? r[key] : "";
  };
  const raNama = String(g("Rencana Aksi") ?? "")
    .trim()
    .toLowerCase();
  const ra =
    ras.find((x) => x.nama.trim().toLowerCase() === raNama) ??
    ras.find((x) => raNama && x.nama.toLowerCase().includes(raNama));
  return {
    id: newId(),
    rencanaAksiId: ra?.id ?? "",
    tanggal: normTanggal(g("Tanggal Kegiatan", "Tanggal")),
    jamMulai: normJam(g("Jam Mulai")),
    jamSelesai: normJam(g("Jam Selesai")),
    kegiatan: String(g("Rencana Kegiatan Harian", "Kegiatan") ?? ""),
    realisasi: String(g("Realisasi") ?? ""),
    linkBukti: String(g("Bukti Dukung", "Link Bukti Dukung") ?? ""),
    selesai: false,
    status: "draft",
  };
}

export async function importExcel(file: File, ras: RencanaAksi[]): Promise<Progres[]> {
  const wb = XLSX.read(await file.arrayBuffer());
  const name = wb.SheetNames[0];
  if (!name) return [];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(wb.Sheets[name]!, { defval: "" });
  return rows.map((r) => rowToProgres(r, ras)).filter((p) => p.tanggal && p.kegiatan);
}

export function exportExcel(list: Progres[], ras: RencanaAksi[], filename: string) {
  const data = list.map((p) => ({
    "Tanggal Kegiatan": p.tanggal,
    "Jam Mulai": p.jamMulai,
    "Jam Selesai": p.jamSelesai,
    "Rencana Aksi": ras.find((r) => r.id === p.rencanaAksiId)?.nama ?? "",
    "Rencana Kegiatan Harian": p.kegiatan,
    Realisasi: p.realisasi,
    "Bukti Dukung": p.linkBukti,
  }));
  const ws = XLSX.utils.json_to_sheet(data, { header: [...KOLOM] });
  ws["!cols"] = [14, 10, 10, 45, 55, 10, 45].map((wch) => ({ wch }));
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Progres Harian");
  XLSX.writeFile(wb, filename);
}

/** Clipboard payload read by the bookmarklet panel on e-Kinerja. */
export function toPayload(list: Progres[], ras: RencanaAksi[]) {
  return JSON.stringify({
    __progresHarian: 2,
    items: list.map((p) => ({
      rencanaAksi: ras.find((r) => r.id === p.rencanaAksiId)?.nama ?? "",
      tanggal: p.tanggal,
      jamMulai: p.jamMulai,
      jamSelesai: p.jamSelesai,
      kegiatan: p.kegiatan,
      realisasi: p.realisasi,
      linkBukti: p.linkBukti,
      selesai: p.selesai,
    })),
  });
}

/** Salin teks ke clipboard; jatuh kembali ke cara lama bila izin clipboard ditolak. */
export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.cssText = "position:fixed;top:0;left:0;opacity:0";
      document.body.appendChild(ta);
      ta.focus();
      ta.select();
      const ok = document.execCommand("copy");
      ta.remove();
      return ok;
    } catch {
      return false;
    }
  }
}

export function bookmarkletHref() {
  return "javascript:" + encodeURIComponent(`(${ekinerjaFiller.toString()})()`);
}
